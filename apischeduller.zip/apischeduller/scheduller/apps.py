from django.apps import AppConfig


class SchedullerConfig(AppConfig):
    name = 'scheduller'
