from django.contrib import admin
from django.urls import

from . import views

#from  scheduller import views
urlpatterns = [
   
    #path('',views.home)),
]
