from django.shortcuts import render

from django.http import HttpResponse
# Create your views here.

from django.http import JsonResponse
from datetime import datetime, timedelta , date, time

from .models import Sceduller
def home(requests):
    
    u=requests.GET["url"]
    s=requests.GET["time"]

   #time is in format year-month-day:hour:minute so need to extact 
    Time=s.split('/')

    a=Time[0].split('-')

    year=int(a[0])
    month=int(a[1])
    day=int(a[2])

    b=Time[1].split(':')

    hour=int(b[0])
    minute=int(b[1])
    t=timedelta()
    d = date(year, month, day)
    t= time(hour,minute)
    mn=datetime.combine(d, t)

    #print(mn)
    s= Sceduller(url=u,time=mn)
    s.save()
    
    return HttpResponse("Sucessfully schedule done .....")






def ping(requests):


    response_data={'status':'ok'}

    return JsonResponse(response_data)


def CheckUrl(requests):
       # to check whether url is schedulled or not 
    try:
        url=requests.GET["url"]
        a=Sceduller.objects.get(url=str(url))  # 
        #print(a)
        curtime=datetime.now()
        threshold= timedelta(minutes =1)
        # Threshold of  minutes for the matching of time with current time
        if(curtime<=a +threshold):

            return HttpResponse(status=200)  # status of OK
        else:
            return HttpResponse(status=404)  # status of response 404    
            
   


    except:
         return HttpResponse("Url not  exits");
        
   
  


#http://localhost:8080/?url=solve&time=2020-04-09/22:52