from django.shortcuts import render

from django.http import HttpResponse
# Create your views here.


def home(requests):


    print("PATH"+requests.path)
    return HttpResponse("hii")
    