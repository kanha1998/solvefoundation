from django.db import models


class Sceduller(models.Model):
    Url = models.CharField(max_length=30)
    time = models.DateField()

